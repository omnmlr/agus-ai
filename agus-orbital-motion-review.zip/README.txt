AGUS AI — Orbital in Motion
Review revision: 92932dc754185e46e72fbecea9f1a51c02905628

1. Extract this archive.
2. Open a terminal in the extracted folder and run: node review.mjs
3. Open the Homepage or Console URL printed in the terminal. The console
   uses the printed disposable email and password. All services bind only
   to your computer. Use Node.js 24. No npm install is required.

The playback in the homepage is an evidence-based reconstruction. The local
console runs against a fresh file store with a synthetic project and APK.
Google, Resend, device allocation, settlement, and private Work are outside
this standalone preview. Stop the review with Ctrl+C.

Deployment handoff:
https://github.com/omnmlr/agus-ai/blob/92932dc754185e46e72fbecea9f1a51c02905628/docs/web-design/orbital-motion.md
